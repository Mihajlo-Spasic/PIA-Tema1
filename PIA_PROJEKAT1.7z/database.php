<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


$db = "PIAproject";
$table = "users";
$connection = new mysqli("localhost","root","","piaproject") or exit("affaf");

?>